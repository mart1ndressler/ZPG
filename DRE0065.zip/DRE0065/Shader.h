#ifndef SHADER_H
#define SHADER_H

#include <GL/glew.h>
#include <string>

using namespace std;

class Shader
{
public:
    Shader(const char* vertexPath, const char* fragmentPath);
    void use() const;

private:
    GLuint programID;
    string readShaderFile(const char* filePath);
    void checkCompilation(GLuint shader);
};

#endif