#ifndef APP_H
#define APP_H

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "Shader.h"
#include "Model.h"

class App
{
public:
    App();
    ~App();
    void run();

private:
    GLFWwindow* window;
    Shader* shader1;
    Shader* shader2;
    Model* model;

    void initWindow();
    void initOpenGL();
};

#endif