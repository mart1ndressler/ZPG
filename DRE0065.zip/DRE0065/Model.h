#ifndef MODEL_H
#define MODEL_H

#include <GL/glew.h>
#include "Shader.h"

class Model
{
public:
    Model();
    ~Model();

    void setupModel();
    void setupSecondModel();
    void draw(const Shader& shader);
    void drawSecondModel(const Shader& shader);

private:
    unsigned int VAO, VBO, VAO2, VBO2;
};

#endif