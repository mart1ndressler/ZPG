#include "App.h"
#include <iostream>

using namespace std;

App::App()
{
    initWindow();
    initOpenGL();

    shader1 = new Shader("vertex_shader.glsl", "fragment_shader.glsl");
    shader2 = new Shader("vertex_shader.glsl", "fragment_shader1.glsl");
    model = new Model();
}

App::~App()
{
    delete shader1;
    delete shader2;
    delete model;
    glfwDestroyWindow(window);
    glfwTerminate();
}

void App::initWindow()
{
    if (!glfwInit())
    {
        cerr << "ERROR: could not start GLFW3\n";
        exit(EXIT_FAILURE);
    }

    window = glfwCreateWindow(800, 600, "ZPG", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
}

void App::initOpenGL()
{
    glewExperimental = GL_TRUE;
    glewInit();

    printf("OpenGL Version: %s\n", glGetString(GL_VERSION));
    printf("Using GLEW %s\n", glewGetString(GL_VERSION));
    printf("Vendor %s\n", glGetString(GL_VENDOR));
    printf("Renderer %s\n", glGetString(GL_RENDERER));
    printf("GLSL %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));
    int major, minor, revision;
    glfwGetVersion(&major, &minor, &revision);
    printf("Using GLFW %i.%i.%i\n", major, minor, revision);
}

void App::run()
{
    while (!glfwWindowShouldClose(window))
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        shader1->use();
        model->draw(*shader1);

        shader2->use();
        model->drawSecondModel(*shader2);

        glfwPollEvents();
        glfwSwapBuffers(window);
    }
}